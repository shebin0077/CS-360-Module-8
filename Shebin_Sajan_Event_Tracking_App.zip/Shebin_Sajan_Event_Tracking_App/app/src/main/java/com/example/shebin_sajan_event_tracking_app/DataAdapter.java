package com.example.shebin_sajan_event_tracking_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
    private Context context;
    private List<Event> dataList;
    private DatabaseHelper dbHelper;

    //  Constructor to Include Context
    public DataAdapter(Context context, List<Event> dataList) {
        this.context = context;
        this.dataList = dataList;
        this.dbHelper = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_data, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Event event = dataList.get(position);
        holder.textViewName.setText(event.getName());
        holder.textViewDate.setText(event.getDate());

        // Delete event from database when clicking "Delete"
        holder.buttonDelete.setOnClickListener(v -> {
            int eventId = event.getId(); // Get event ID
            dbHelper.deleteEvent(eventId); // Delete from database
            dataList.remove(position); // Remove from list
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, dataList.size());
        });
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewName, textViewDate;
        Button buttonDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textViewName);
            textViewDate = itemView.findViewById(R.id.textViewDate);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}
