package com.example.shebin_sajan_event_tracking_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    // Declare UI elements and database helper
    private EditText usernameEditText, passwordEditText;
    private Button loginButton, createAccountButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the layout for this activity
        setContentView(R.layout.activity_main);

        // Initialize the database helper
        dbHelper = new DatabaseHelper(this);

        // Find and assign UI elements by their IDs
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        loginButton = findViewById(R.id.login_button);
        createAccountButton = findViewById(R.id.create_account_button);

        // Set click listener for the login button
        loginButton.setOnClickListener(v -> {
            // Get username and password from the input fields
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            // Check if username or password is empty
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                return; // Exit the function if fields are empty
            }

            // Check if the user exists in the database
            if (!dbHelper.checkUserExists(username)) {
                Toast.makeText(MainActivity.this, "User does not exist", Toast.LENGTH_SHORT).show();
                return; // Exit the function if the user doesn't exist
            }

            // Validate user credentials
            if (dbHelper.checkUserCredentials(username, password)) {
                // If credentials are valid, get the user ID
                int userId = dbHelper.getUserId(username);

                // Create an intent to navigate to the DataActivity
                Intent intent = new Intent(MainActivity.this, DataActivity.class);
                intent.putExtra("USER_ID", userId); // Pass the user ID to the next activity
                startActivity(intent); // Start the new activity
                finish(); // Close the current activity
            } else {
                // Show error message if the password is invalid
                Toast.makeText(MainActivity.this, "Invalid Password", Toast.LENGTH_SHORT).show();
            }
        });

        // Set click listener for the create account button
        createAccountButton.setOnClickListener(v -> {
            // Navigate to the RegisterActivity
            startActivity(new Intent(MainActivity.this, RegisterActivity.class));
        });
    }
}