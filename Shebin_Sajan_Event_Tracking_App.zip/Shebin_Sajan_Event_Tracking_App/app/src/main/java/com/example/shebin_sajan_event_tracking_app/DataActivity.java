package com.example.shebin_sajan_event_tracking_app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DataActivity extends AppCompatActivity {
    private EditText editTextName, editTextDate;
    private Button buttonAdd, buttonLogout;
    private RecyclerView recyclerView;
    private DataAdapter adapter;
    private DatabaseHelper dbHelper;
    private int userId; // Store logged-in user ID

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // Initialize Database Helper
        dbHelper = new DatabaseHelper(this);

        // Get User ID from Intent (Passed from Login)
        userId = getIntent().getIntExtra("USER_ID", -1);
        if (userId == -1) {
            Toast.makeText(this, "Error: User not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        //  Initialize Views (Matching XML IDs)
        editTextName = findViewById(R.id.editTextName);
        editTextDate = findViewById(R.id.editTextDate);
        buttonAdd = findViewById(R.id.buttonAdd);
        buttonLogout = findViewById(R.id.buttonLogout);
        recyclerView = findViewById(R.id.recyclerView);

        //  Set RecyclerView Properties
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //  Load Existing Events
        loadEvents();

        //  Add Event Button Click
        buttonAdd.setOnClickListener(v -> addEvent());

        // Logout Button Click
        buttonLogout.setOnClickListener(v -> {
            Intent intent = new Intent(DataActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }

    //  Method to Load Events from Database
    private void loadEvents() {
        List<Event> eventList = dbHelper.getUserEvents(userId);
        adapter = new DataAdapter(this, eventList);
        recyclerView.setAdapter(adapter);
    }

    // Method to Add New Event
    private void addEvent() {
        String eventName = editTextName.getText().toString().trim();
        String eventDate = editTextDate.getText().toString().trim();

        if (eventName.isEmpty() || eventDate.isEmpty()) {
            Toast.makeText(this, "Please enter event name and date", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean inserted = dbHelper.insertEvent(eventName, eventDate, userId);
        if (inserted) {
            Toast.makeText(this, "Event added successfully", Toast.LENGTH_SHORT).show();
            editTextName.setText("");
            editTextDate.setText("");
            loadEvents(); // Refresh events
        } else {
            Toast.makeText(this, "Error adding event", Toast.LENGTH_SHORT).show();
        }
    }
}
