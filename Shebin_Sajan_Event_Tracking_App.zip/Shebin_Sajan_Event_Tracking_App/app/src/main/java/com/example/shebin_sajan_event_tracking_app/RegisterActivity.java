package com.example.shebin_sajan_event_tracking_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    // Declare UI elements and database helper
    private EditText newUsernameEditText, newPasswordEditText;
    private Button createAccountButton, backButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set the layout for this activity
        setContentView(R.layout.activity_register);

        // Initialize the database helper
        dbHelper = new DatabaseHelper(this);

        // Find and assign UI elements by their IDs
        newUsernameEditText = findViewById(R.id.new_username);
        newPasswordEditText = findViewById(R.id.new_password);
        createAccountButton = findViewById(R.id.create_account_button);
        backButton = findViewById(R.id.back_button);

        // Set click listener for the create account button
        createAccountButton.setOnClickListener(v -> {
            // Get username and password from the input fields
            String username = newUsernameEditText.getText().toString().trim();
            String password = newPasswordEditText.getText().toString().trim();

            // Check if username or password is empty
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return; // Exit the function if fields are empty
            }

            // Check if the username already exists in the database
            if (dbHelper.checkUserExists(username)) {
                Toast.makeText(RegisterActivity.this, "Username already exists", Toast.LENGTH_SHORT).show();
                return; // Exit the function if the username is already taken
            }

            // Attempt to insert the new user into the database
            if (dbHelper.insertUser(username, password)) {
                // If insertion is successful, show a success message
                Toast.makeText(RegisterActivity.this, "Account Created Successfully", Toast.LENGTH_SHORT).show();
                // Navigate back to the MainActivity
                startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                finish(); // Close the current activity
            } else {
                // Show an error message if account creation fails
                Toast.makeText(RegisterActivity.this, "Error Creating Account", Toast.LENGTH_SHORT).show();
            }
        });

        // Set click listener for the back button
        backButton.setOnClickListener(v -> {
            // Navigate back to the MainActivity
            startActivity(new Intent(RegisterActivity.this, MainActivity.class));
        });
    }
}