package com.example.shebin_sajan_event_tracking_app;

public class DataItem {
    private String data;

    public DataItem(String data) {
        this.data = data;
    }

    public String getData() {
        return data;
    }
}
